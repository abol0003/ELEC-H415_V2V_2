import numpy as np
class Material:
    def __init__(self, name, permittivity, color):
        self.name = name
        self.permittivity = permittivity
        self.color = color